﻿function validaApellido() {
    validacion = document.getElementById("txtApellido")
    letras = validacion.value;
    parent = validacion.parentElement;
    texto = document.createElement('DIV');
    texto.setAttribute("id", "Apellido")
    texto.innerHTML = '<span> Falta apellido </span>';
    if (letras == null || letras == "" || /^[0-9]+$/.test(letras)) {
        validacion.setAttribute("class", "error")
        if (document.getElementById("Apellido") === null) {
            parent.appendChild(texto)
        }

    } else {
        element = document.getElementById("Apellido")
        if (element !== null) {
            parent.removeChild(element)
        }
        validacion.setAttribute("class", "texto")
    }
}

function validaNombre() {
    validacion = document.getElementById("txtNombre")
    letras = validacion.value;
    parent = validacion.parentElement;
    texto = document.createElement('DIV');
    texto.setAttribute("id", "Nombre")
    texto.innerHTML = '<span> Falta nombre </span>';
    if (letras == null || letras == "" || /^[0-9]+$/.test(letras)) {
        validacion.setAttribute("class", "error")

        if (document.getElementById("Nombre") === null) {
            parent.appendChild(texto)
        }
    } else {
        element = document.getElementById("Nombre")
        if (element !== null) {
            parent.removeChild(element)
        }
        validacion.setAttribute("class", "texto")
    }
}

function validaEmail() {
    email = document.getElementById("txtEmail")
    valorEmail = email.value;
    parent = email.parentElement;
    emailValido = document.createElement('DIV');
    emailValido.setAttribute("id", "txtemailValido")
    emailValido.innerHTML = '<span> El correo no es válido, verifique que tenga @ y finalice en .com </span>';
    if (!email.checkValidity() || !(/\.[a-z]{3}$/.test(valorEmail))) {
        email.setAttribute("class", "error")

        if (document.getElementById("txtemailValido") === null) {
            parent.appendChild(emailValido)
        }
    } else {
        element = document.getElementById("txtemailValido")
        if (element !== null) {
            parent.removeChild(element)
        }
        email.setAttribute("class", "texto")
    }
}

function validarDNI() {
    dni = document.getElementById("txtDNI")
    valorDni = dni.value;
    parent = dni.parentElement;
    dniValido = document.createElement('DIV');
    dniValido.setAttribute("id", "txtDNIValido")
    dniValido.innerHTML = '<span> El DNI no es correcto, ingrese solo números>';
    if (parseInt(valorDni)=="NaN") {
        dni.setAttribute("class", "error")

        if (document.getElementById("txtDNIlValido") === null) {
            parent.appendChild(dniValido)
        }
    } else {
        element = document.getElementById("txtDNIValido")
        if (element !== null) {
            parent.removeChild(element)
        }
        dni.setAttribute("class", "texto")
    }

}

function confirmacion() {

    validacion = document.getElementById("numero1");
    validacion2 = document.getElementById("numero2");
    letras = validacion.value;
    letras2 = validacion2.value;
    if (letras == null || letras == "" || /^[0-9]+$/.test(letras)) {
        validacion.setAttribute("class", "error")
        alert("Escriba apellido correctamente")

    }
    if (letras2 == null || letras2 == "" || /^[0-9]+$/.test(letras2)) {
        validacion2.setAttribute("class", "error")
        alert("Escriba nombre correctamente")
    }
    validacion3 = document.getElementById("numero3")
    letras3 = validacion3.value
    if (/[A-Za-z]+$/.test(letras3)) {
        validacion3.setAttribute("class", "error")
        alert("Escriba en numero el DNI")
    }
    validacion4 = document.getElementById("numero4")
    letras3 = validacion4.value
    if (letras3 != null || letras3 != "f" || letras3 != "m" || letras3 == "") {
        validacion4.setAttribute("class", "error")
        alert("Escriba f o m")
    }

}

function tecla(id) {
    validacion = document.getElementById(id)
    validacion.setAttribute("class", "onkeydown")
}

function mouse(id) {
    validacion = document.getElementById(id)
    validacion.setAttribute("class", "onmouseover")
}

function confirmacion() {

    validacion = document.getElementById("numero1");
    validacion2 = document.getElementById("numero2");
    letras = validacion.value;
    letras2 = validacion2.value;
    if (letras == null || letras == "" || /^[0-9]+$/.test(letras)) {
        validacion.setAttribute("class", "error")
        alert("Escriba apellido correctamente")

    }
    if (letras2 == null || letras2 == "" || /^[0-9]+$/.test(letras2)) {
        validacion2.setAttribute("class", "error")
        alert("Escriba nombre correctamente")
    }

}

function validaciones_genericas() {
    inputtexto = document.getElementById('txtApellido')
    inputtexto2 = document.getElementById('txtNombre')
    valortexto1 = inputtexto.value;
    valortexto2 = inputtexto2.value;
    if (!(/[A-Za-z]+$/.test(valortexto1))) {
        alert("Escriba solo texto para el campo apellido")
        return false;
    }
    if (!(/[A-Za-z]+$/.test(valortexto2))) {
        alert("Escriba solo texto para el campo nombre")
        return false;
    }
    if (!inputtexto.checkValidity()) {
        alert("Escriba solo 25 caracteres campo apellido")
        return false;
    }
    if (!inputtexto2.checkValidity()) {
        alert("Escriba solo 25 caracteres campo nombre")
        return false;
    }
    if (!inputCantidad.validity) {
        alert("Escriba solo 25 caracteres ")
        return false;
    return true;
}