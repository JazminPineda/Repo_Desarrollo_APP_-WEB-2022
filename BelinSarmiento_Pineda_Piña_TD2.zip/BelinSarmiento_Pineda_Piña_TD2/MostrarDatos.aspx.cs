﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace TP2_Desa_app
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection("Data Source=DESKTOP-PL15KVP;Initial Catalog=AlumnosDB;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;");
            conexion.Open();

            string consulta = ("select Apellido, Nombre, DNI, Email, Turno from alumnos where idAlumno=(select MAX(idAlumno) from alumnos)");

            SqlCommand comando = new SqlCommand(consulta, conexion);

            SqlDataReader leer = comando.ExecuteReader();

            mostrar.DataSource = leer;
            mostrar.DataBind();

            conexion.Close();

        }
        protected void Enviar_Coment(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=DESKTOP-PL15KVP;Initial Catalog=AlumnosDB;Integrated Security=True;Persist Security Info=False;Pooling=False;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;");
            conn.Open();

            string comentario = "insert into comentarios (Comentario) values ('"+txtComentario.Text+"')";

            SqlCommand comando = new SqlCommand(comentario, conn);

            comando.ExecuteNonQuery();

            conn.Close();

            Response.Redirect("IngresoAlumno.aspx");
        }

    }
}